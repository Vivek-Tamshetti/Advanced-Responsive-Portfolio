document.addEventListener("DOMContentLoaded", () => {
    
    const root = document.documentElement;
    const themeToggleBtn = document.getElementById("theme-toggle");

    const getInitialTheme = () => {
        const savedTheme = localStorage.getItem("portfolio-theme");
        if (savedTheme === "light" || savedTheme === "dark") {
            return savedTheme;
        }
        return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    };

    const applyTheme = (theme) => {
        root.setAttribute("data-theme", theme);
        localStorage.setItem("portfolio-theme", theme);
    };

    applyTheme(getInitialTheme());

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener("click", () => {
            const currentTheme = root.getAttribute("data-theme") || getInitialTheme();
            const nextTheme = currentTheme === "dark" ? "light" : "dark";
            applyTheme(nextTheme);
        });
    }

    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
        if (!localStorage.getItem("portfolio-theme")) {
            applyTheme(e.matches ? "dark" : "light");
        }
    });

    const navToggleBtn = document.getElementById("nav-toggle");
    const navMenu = document.getElementById("nav-menu");

    if (navToggleBtn && navMenu) {
        const toggleMenu = () => {
            const isExpanded = navToggleBtn.getAttribute("aria-expanded") === "true";
            navToggleBtn.setAttribute("aria-expanded", String(!isExpanded));
            navMenu.classList.toggle("open");
        };

        const closeMenu = () => {
            navToggleBtn.setAttribute("aria-expanded", "false");
            navMenu.classList.remove("open");
        };

        navToggleBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            toggleMenu();
        });

        navMenu.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                closeMenu();
            });
        });

        document.addEventListener("click", (event) => {
            if (!navToggleBtn.contains(event.target) && !navMenu.contains(event.target)) {
                closeMenu();
            }
        });

        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape" && navMenu.classList.contains("open")) {
                closeMenu();
                navToggleBtn.focus();
            }
        });
    }

    const currentPath = window.location.pathname.split("/").pop() || "index.html";
    const navLinks = document.querySelectorAll(".nav-menu a");

    navLinks.forEach((link) => {
        const href = link.getAttribute("href");
        if (href === currentPath || (currentPath === "" && href === "index.html")) {
            link.setAttribute("aria-current", "page");
        } else {
            link.removeAttribute("aria-current");
        }
    });

    const yearElements = document.querySelectorAll("#year, .year");
    const currentYear = new Date().getFullYear();
    yearElements.forEach((el) => {
        el.textContent = currentYear;
    });

    const urlParams = new URLSearchParams(window.location.search);
    const subjectParam = urlParams.get("subject");
    const subjectInput = document.getElementById("subject");
    if (subjectParam && subjectInput) {
        subjectInput.value = subjectParam;
    }

    const contactForm = document.getElementById("contact-form");

    if (contactForm) {
        const inputs = contactForm.querySelectorAll("input, textarea");
        const status = document.getElementById("form-status");

        inputs.forEach((input) => {
            input.addEventListener("input", () => {
                if (status && status.textContent && status.style.color === "rgb(255, 107, 107)") {
                    status.textContent = "";
                }
            });
        });

        contactForm.addEventListener("submit", function(event) {
            event.preventDefault();

            const name = document.getElementById("name");
            const email = document.getElementById("email");
            const message = document.getElementById("message");

            if (
                name.value.trim() === "" ||
                email.value.trim() === "" ||
                message.value.trim() === ""
            ) {
                status.textContent = "Please fill in all required fields.";
                status.style.color = "#ff6b6b";
                return;
            }

            if (!email.validity.valid) {
                status.textContent = "Please enter a valid email address.";
                status.style.color = "#ff6b6b";
                email.focus();
                return;
            }

            status.style.color = "var(--PRIMARY-COLOR)";
            status.textContent = `Thank you, ${name.value.trim()}! Your message has been sent successfully. (Demo mode)`;

            contactForm.reset();
        });
    }
});
